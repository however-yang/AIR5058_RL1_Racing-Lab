"""Implement your training reward here. See the assignment brief."""

from dataclasses import dataclass


@dataclass(frozen=True)
class RewardSignals:
    progress_delta_m: float       # Signed change in centerline arc length
    lateral_error_m: float       # Positive to the left of the centerline
    heading_error_rad: float     # Car yaw minus track yaw, wrapped to [-pi, pi]
    speed_mps: float             # Signed forward speed
    steering: float              # Normalized command in [-1, 1]
    steering_change: float       # Signed change from the previous command
    dt_s: float                  # Elapsed simulation time for this step
    finished: bool
    off_track: bool
    timed_out: bool


def reward(signals: RewardSignals) -> float:
    """Smoke-test reward. Replace it with your own shaping before training."""
    return float(signals.finished)

"""Gymnasium environment shared by training, evaluation, and replay."""

import math
from pathlib import Path
from xml.etree import ElementTree as ET

import gymnasium as gym
import mujoco
import numpy as np

from .reward import RewardSignals
from .reward import reward as student_reward
from .track import Track


class RaceEnv(gym.Env):
    metadata = {"render_modes": ["rgb_array"], "render_fps": 20}
    max_speed = 5.0
    max_steer = .54
    time_limit = 26.
    frame_skip = 5
    lookahead = np.array([.6, 1.3, 2.2, 3.5, 5.0])
    corners = np.array([[.28, .203], [.28, -.203], [-.28, .203], [-.28, -.203]])

    def __init__(self, reward_fn=student_reward, render_mode=None):
        self.track = Track()
        xml = Path(__file__).with_name("car.xml")
        if render_mode == "rgb_array":
            tree = ET.parse(xml)
            self.track.add_visuals(tree.getroot())
            self.model = mujoco.MjModel.from_xml_string(ET.tostring(tree.getroot(), encoding="unicode"))
        else:
            self.model = mujoco.MjModel.from_xml_path(str(xml))
        self.data = mujoco.MjData(self.model)
        self.car = self.model.body("car").id
        self.steer_qpos = self.model.joint("steer_left").qposadr.item()
        self.action_space = gym.spaces.Box(-1., 1., (2,), np.float32)
        self.observation_space = gym.spaces.Box(-10., 10., (18,), np.float32)
        self.reward_fn = reward_fn
        self.render_mode = render_mode
        self.renderer = None

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        mujoco.mj_resetData(self.model, self.data)
        self.arc = -.65
        center, self.segment = self.track.sample(self.arc)
        tangent = self.track.tangents[self.segment]
        lateral, heading = self.np_random.uniform([-.25, -.14], [.25, .14])
        yaw = math.atan2(tangent[1], tangent[0]) + heading
        self.data.qpos[:2] = center + lateral * np.array([-tangent[1], tangent[0]])
        self.data.qpos[3:7] = [math.cos(yaw / 2), 0, 0, math.sin(yaw / 2)]
        mujoco.mj_forward(self.model, self.data)
        self.next_gate = 0
        self.max_progress = 0.
        self.last_steering = 0.
        obs, _, _, _ = self._observe()
        return obs, self._info("running")

    def step(self, action):
        steering, speed = np.clip(action, -1., 1.)
        self.data.ctrl[:2] = self.max_steer * steering
        self.data.ctrl[2:] = (speed + 1.) * .5 * self.max_speed / .086
        before_arc, before_time = self.arc, self.data.time
        status = "running"

        for _ in range(self.frame_skip):
            mujoco.mj_step(self.model, self.data)
            # mj_step integrates qpos after computing body transforms.
            mujoco.mj_kinematics(self.model, self.data)
            yaw = self._yaw()
            c, s = math.cos(yaw), math.sin(yaw)
            rotation = np.array([[c, s], [-s, c]])
            position = self.data.qpos[:2]
            points = np.vstack((position, position + self.corners @ rotation))
            segments, arcs, distances = self.track.project(points, self.segment)
            if distances.max() > self.track.half_width ** 2 or self.data.xmat[self.car, 8] < .5:
                status = "off_track"
                break
            self.segment = segments[0]
            lap = self.track.length
            delta = (arcs[0] - self.arc + lap / 2.) % lap - lap / 2.
            previous = self.arc
            self.arc += delta
            if previous < self.track.gates[self.next_gate] <= self.arc:
                self.next_gate += 1
            progress_limit = self.track.gates[min(self.next_gate, len(self.track.gates) - 1)]
            self.max_progress = max(self.max_progress, float(min(self.arc, progress_limit) / lap))
            if self.next_gate == len(self.track.gates):
                status = "finished"
                break

        if status == "running" and self.data.time >= self.time_limit - 1e-9:
            status = "timeout"
        steering_change = steering - self.last_steering
        self.last_steering = float(steering)
        obs, lateral, heading, forward = self._observe()
        signals = RewardSignals(
            progress_delta_m=float(self.arc - before_arc),
            lateral_error_m=float(lateral), heading_error_rad=heading, speed_mps=forward,
            steering=float(steering), steering_change=float(steering_change),
            dt_s=float(self.data.time - before_time), finished=status == "finished",
            off_track=status == "off_track", timed_out=status == "timeout",
        )
        return obs, float(self.reward_fn(signals)), status in ("off_track", "finished"), status == "timeout", self._info(status)

    def _yaw(self):
        mat = self.data.xmat[self.car]
        return math.atan2(mat[3], mat[0])

    def _observe(self):
        yaw = self._yaw()
        c, s = math.cos(yaw), math.sin(yaw)
        rotation = np.array([[c, -s], [s, c]])
        position = self.data.qpos[:2]
        center, idx = self.track.sample(self.arc)
        tangent = self.track.tangents[idx]
        lateral = (position - center) @ np.array([-tangent[1], tangent[0]])
        heading = (yaw - math.atan2(tangent[1], tangent[0]) + math.pi) % (2 * math.pi) - math.pi
        forward, sideways = self.data.qvel[:2] @ rotation
        targets, _ = self.track.sample(self.arc + self.lookahead)
        local = (targets - position) @ rotation / self.lookahead[-1]
        observation = np.r_[local.ravel(), lateral / self.track.half_width,
                            math.sin(heading), math.cos(heading),
                            forward / self.max_speed, sideways / self.max_speed,
                            self.data.qvel[5] / 5., self.data.qpos[self.steer_qpos] / self.max_steer,
                            self.last_steering]
        return np.clip(observation, -10., 10.).astype(np.float32), lateral, heading, float(forward)

    def _info(self, status):
        return {"status": status, "progress": self.max_progress,
                "gates": self.next_gate, "time_s": float(self.data.time)}

    def render(self):
        if self.render_mode != "rgb_array":
            return None
        if self.renderer is None:
            self.renderer = mujoco.Renderer(self.model, height=600, width=960)
        self.renderer.update_scene(self.data, camera="overview")
        return self.renderer.render()

    def close(self):
        if self.renderer is not None:
            self.renderer.close()
            self.renderer = None

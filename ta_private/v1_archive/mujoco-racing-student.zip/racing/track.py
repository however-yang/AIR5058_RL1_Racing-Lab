"""Sampled closed centerline, arc length and track visuals."""

import math
from xml.etree import ElementTree as ET

import numpy as np


class Track:
    half_width = 1.05

    def __init__(self):
        t = np.linspace(0, 2 * np.pi, 241, endpoint=False)
        self.points = np.column_stack((7.3 * np.cos(t) + 1.2 * np.sin(2 * t),
                                       4.5 * np.sin(t) + .7 * np.cos(2 * t)))
        self.edges = np.roll(self.points, -1, axis=0) - self.points
        self.lengths = np.linalg.norm(self.edges, axis=1)
        self.tangents = self.edges / self.lengths[:, None]
        self.arc = np.r_[0., np.cumsum(self.lengths)]
        self.length = float(self.arc[-1])
        self.gates = np.linspace(self.length / 8, self.length, 8)
        self.neighbors = (np.arange(len(t))[:, None] + np.arange(-13, 14)) % len(t)
        self.local_points = self.points[self.neighbors]
        self.local_tangents = self.tangents[self.neighbors]
        self.local_lengths = self.lengths[self.neighbors]

    def sample(self, arc):
        distance = np.asarray(arc) % self.length
        # A tiny negative arc can round to length after wrapping.
        distance = np.where(distance < self.length, distance, 0.)
        idx = np.searchsorted(self.arc, distance, side="right") - 1
        return self.points[idx] + (distance - self.arc[idx])[..., None] * self.tangents[idx], idx

    def project(self, positions, near):
        """Project a batch of points near the last known road segment."""
        tangents = self.local_tangents[near]
        offsets = positions[:, None, :] - self.local_points[near]
        along = np.clip(np.einsum("mni,ni->mn", offsets, tangents),
                        0., self.local_lengths[near])
        residual = offsets - along[..., None] * tangents
        squared = np.einsum("mni,mni->mn", residual, residual)
        rows = np.arange(len(positions))
        best = squared.argmin(axis=1)
        segments = self.neighbors[near, best]
        return segments, self.arc[segments] + along[rows, best], squared[rows, best]

    def add_visuals(self, model):
        assets = ET.SubElement(model, "asset")
        world = model.find("worldbody")
        def strip(a, b, half_width, z, color):
            x, y = (a + b) / 2
            dx, dy = b - a
            ET.SubElement(world, "geom", type="box", pos=f"{x} {y} {z}",
                          euler=f"0 0 {math.atan2(dy, dx)}",
                          size=f"{math.hypot(dx, dy) / 2 + .02} {half_width} .001",
                          rgba=color, contype="0", conaffinity="0")

        normals = self.tangents[:, ::-1] * [-1, 1]
        def band(name, left, right, height, color):
            vertices, faces = [], []
            for a, b in zip(self.points + left * normals, self.points + right * normals):
                vertices.extend([(*a, height), (*b, height), (*a, height - .001), (*b, height - .001)])
            for i in range(len(self.points)):
                a, b, c, d = range(4 * i, 4 * i + 4)
                j = 4 * ((i + 1) % len(self.points))
                e, f, g, h = range(j, j + 4)
                faces.extend([(a, b, f), (a, f, e), (c, g, h), (c, h, d),
                              (a, e, g), (a, g, c), (b, d, h), (b, h, f)])
            ET.SubElement(assets, "mesh", name=name,
                          vertex=" ".join(str(x) for vertex in vertices for x in vertex),
                          face=" ".join(str(x) for face in faces for x in face))
            ET.SubElement(world, "geom", type="mesh", mesh=name, rgba=color,
                          contype="0", conaffinity="0")

        w = self.half_width
        band("asphalt", w, -w, .003, ".17 .20 .24 1")
        band("inner_line", w + .022, w - .022, .006, ".88 .90 .92 1")
        band("outer_line", -w + .022, -w - .022, .006, ".88 .90 .92 1")

        for gate in self.gates:
            center, idx = self.sample(gate)
            offset = self.half_width * normals[idx]
            color = ".98 .75 .22 1" if gate == self.length else ".38 .41 .45 1"
            strip(center - offset, center + offset, .045, .008, color)
